Research paper LaTeX project

Main file: main.tex
Bibliography: references.bib
Figure: figures/fraud_detection_methodology.pdf
Compiled output: main.pdf

The manuscript is formatted using IEEEtran conference style. Compile with pdfLaTeX and BibTeX. The manuscript separates Results and Findings from Discussion, while retaining the professor's required research motivation, major contributions, literature comparison, methodology algorithm, flowchart, and conclusion/future research.
